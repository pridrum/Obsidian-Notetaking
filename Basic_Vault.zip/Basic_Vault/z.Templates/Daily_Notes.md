{{date:YYYY-MM-DD}}

#research-diary 
## Actionable items
```dataview
TASK
WHERE !completed
```
