---
Authors: 
Year: 
Ref: 
Type: mine
Topic: 
Project/Area: 
Status: write, done, incubate
---
>[!important] Project Overview
>**Goal**:
>**Research Questions**: 1) ; 2) 
>**Aspirational Journals**:
>**Possible keywords:** 

```dataview
TASK
WHERE !completed
WHERE file = this.file
```


>[!info] Links for additional files
>- **Overleaf link:** [[LINK|NAME FILE]]
>- **Github/Folder:**  [[LINK|NAME FILE]]
>- **Meeting Minutes**:  [[Project Notetaking Minutes]]
>- **Working files**: [[Project Notetaking Random Ideas]]

# Project idea draft
**Goal**: 

**RQ1**: 
**RQ2:** 

## Methods:
### Assumptions:
### Replications:
### Model testing:
## Literature Review:

## To do:
