---
CiteKey: {{citationKey}}
Type: {{itemType}}
Title: '{{title}}'
Author: '{{authors}}'
Publisher: '{{publisher}}'
Journal: '{{publicationTitle}}'
Year: {{year}} {{date | format("YYYY")}}
DOI: {{DOI}}
Status: read, reviewed, processing, done
Main-Focus: model theory concept algorithm overview data metrics book-review presentation
---


>[!abstract] Summary
**{{title}}** 
**Author**: '{{authors}}' ; {{year}} {{date | format("YYYY")}}
**Motivation**: 
**Research Questions or Gap**:  
**Methods/Algorithm**: 
**Field of Application:**
**Results/Conclusions:** 
**Major take away:** 

>- **Project/Area:**
>- **Tags**: {% for t in tags %}#{{t.tag | replace(' ','-')}} {% endfor %}

---
# Highlights and comments

> [!Quote]  

{% for annotation in annotations %}
	{%- if annotation.annotatedText -%}
		- <mark style="background: {{annotation.colorCategory | lower}}">.</mark> {{annotation.annotatedText}}
{%endif-%}
{% if annotation.imageBaseName %}![[{{annotation.imageBaseName}}]]{% endif %}
{% if annotation.comment %}=={{annotation.comment}}=={% endif %}
{% endfor %}

---
## Reference
>- **Ref**: [[{{citationKey}}]]
>- **DOI**: {{DOI}}
>- **Url**: {{url}}
>- **Uri**: {{uri}}
>- **PDF link**: {{pdfLink}}
>- **Local Library**: [Zotero]({{localLibraryLink}})
>- **Abstract**: {{abstractNote}}