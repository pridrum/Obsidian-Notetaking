>[!idea] Main idea: 

 - Sub idea 1
	 - Sub sub idea 1
	 - Sub sub idea 2
 - Sub idea 2
 - ss