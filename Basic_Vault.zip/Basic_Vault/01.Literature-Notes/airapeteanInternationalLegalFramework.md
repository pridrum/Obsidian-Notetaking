---
CiteKey: airapeteanInternationalLegalFramework
Type: journalArticle
Title: 'International Legal Framework Regarding Human Trafficking'
Author: 'Artur Airapetean, Andreea Corsei'
Publisher: ''
Journal: ''
Year:  Error: `format` can only be applied to dates. Tried for format object
DOI: 
Status: read, review, process, done
Main-focus: model theory concept algorithm review data presentation
---

>[!abstract] Summary
**International Legal Framework Regarding Human Trafficking** 
**Author**: 'Artur Airapetean, Andreea Corsei' ;  Error: `format` can only be applied to dates. Tried for format object
**Motivation**: 
**Research Questions or Gap**:  
**Methods/Algorithm**: 
**Field of Application:**
**Results/Conclusions:** 
**Major take away:** 

>- **Project/Area:**
>- **Tags**: 

---
# Highlights and comments

> [!Quote]  

- <mark style="background: red">.</mark> a special law. That could favor the legislation of all aspects of the crime itself, of those related to it, of the particular aspects of a procedural nature, including those regarding international cooperation in the matter. A


- <mark style="background: green">.</mark> not apply a special treatment to the victims of human trafficking, offering them the necessary protection and assistance, but on the contrary, the victims were accused of prostitution, of illegal border crossi

==This is BS==


---
## Reference
>- **Ref**: [[airapeteanInternationalLegalFramework]]
>- **DOI**: 
>- **Url**: 
>- **Uri**: http://zotero.org/users/2191306/items/M3R9WAH4
>- **Eprint**: 
>- **File**: 
>- **Keywords**: 
>- **PDF link**: [Airapetean and Corsei - International Legal Framework Regarding Human Traf.pdf](file://C:\Users\deazevedodrummond.p.NUNET\Zotero\storage\VRU6XV7R\Airapetean%20and%20Corsei%20-%20International%20Legal%20Framework%20Regarding%20Human%20Traf.pdf)
>- **Local Library**: [Zotero]()
>- **Abstract**: International failures in this field have several causes. Thus, many states have preferred to include the crime of human trafficking in their own criminal codes, without considering it necessary to regulate it through a special law. That could favor the legislation of all aspects of the crime itself, of those related to it, of the particular aspects of a procedural nature, including those regarding international cooperation in the matter. Another cause could be that of criminalizing only human trafficking for the purpose of prostitution, without taking into account the other forms. In addition, most of the laws of the world's states did not apply a special treatment to the victims of human trafficking, offering them the necessary protection and assistance, but on the contrary, the victims were accused of prostitution, of illegal border crossing, of falsifying travel documents, being expelled and repatriated in their country of origin.