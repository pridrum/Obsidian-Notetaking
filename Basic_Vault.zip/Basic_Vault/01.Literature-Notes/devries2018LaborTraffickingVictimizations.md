---
CiteKey: devries2018LaborTraffickingVictimizations
Type: journalArticle
Title: "Labor trafficking victimizations: Repeat victimization and polyvictimization"
Author: Ieke De Vries, Amy Farrell
Publisher: ""
Journal: Psychology of Violence
Year: 2018
DOI: 10.1037/vio0000149
Status: read
Main-Focus: theory
---


>[!abstract] Summary
**Labor trafficking victimizations: Repeat victimization and polyvictimization** 
**Author**: 'Ieke De Vries, Amy Farrell' ;  2018
**Motivation**: 
**Research Questions or Gap**:  
**Methods/Algorithm**: 
**Field of Application:**
**Results/Conclusions:** 
**Major take away:** 

>- **Project/Area:**
>- **Tags**: #Human-Trafficking #In_obsidian #Employment-Status #Test-Construction #Transportation #Victimization 

---
# Highlights and comments

> [!Quote]  



---
## Reference
>- **Ref**: [[devries2018LaborTraffickingVictimizations]]
>- **DOI**: 10.1037/vio0000149
>- **Url**: 
>- **Uri**: http://zotero.org/users/2191306/items/TTIHHERA
>- **PDF link**: 
>- **Local Library**: [Zotero]()
>- **Abstract**: Objective: To examine labor trafficking victimizations as forms of repeat victimization and polyvictimization. Method: The study uses secondary cross-sectional data about 115 labor-trafficked persons in the United States who received services after the labor trafficking experience. Through multivariate regression analyses, victimization patterns were investigated at each primary stage of the trafficking process (recruitment, transportation, employment). Results: Our findings demonstrate patterns of repeat victimization and polyvictimization among labor-trafficked persons. Prior victimization experiences before the onset of the trafficking significantly increased the odds of experiencing victimization during the initial stages of the trafficking process (recruitment and transportation). Victimization experiences during these initial stages further increased the risk of experiencing a higher count of polyvictimization during the final stage of the trafficking process (employment). Conclusions: Our study lays the groundwork for an analytical framework upon which to evaluate labor trafficking. The results call for early intervention and comprehensive assistance programs that take into account enduring and cumulative victimization patterns in order to meet the needs of identified labor-trafficked persons. (PsycINFO Database Record (c) 2018 APA, all rights reserved)