---
CiteKey: amon2023ExploringHeterogeneityFarmers
Type: webpage
Title: "Exploring heterogeneity in farmers’ willingness to cooperate in four EU member states: Insights from public goods games"
Author: Johannes Martin Amon
Publisher: ""
Journal: ""
Year: 2023
DOI: 
Status: done
Main-Focus: data
---

>[!abstract] Summary
**Exploring heterogeneity in farmers’ willingness to cooperate in four EU member states: Insights from public goods games** 
**Author**: 'Johannes Martin Amon' ;  2023
**Motivation**: 
**Research Questions or Gap**:  
**Methods/Algorithm**: 
**Field of Application:**
**Results/Conclusions:** 
**Major take away:** 

>- **Project/Area:**
>- **Tags**: 

---
# Highlights and comments

> [!Quote]  



---
## Reference
>- **Ref**: [[amon2023ExploringHeterogeneityFarmers]]
>- **DOI**: 
>- **Url**: https://stud.epsilon.slu.se/19305/
>- **Uri**: http://zotero.org/users/2191306/items/5RCGCUFX
>- **Eprint**: 
>- **File**: 
>- **Keywords**: 
>- **PDF link**: 
>- **Local Library**: [Zotero]()
>- **Abstract**: Agri-environment-climate measures (AECMs), as part of the European Union’s Common Agricultural Policy, incentivize environmentally friendly farming practices for multiple ecosystem services provision. However, AECMs are criticised for their low cost-effectiveness. Moving towards the collective implementation of AECMs is discussed as a possibility to coordinate ecosystem services provision at larger scale and to economize on administrative costs. The thesis investigates European farmers' willingness to cooperate and the heterogeneity in cooperation by means of public goods game (PGG) experiments conducted with farmers in Germany, Hungary, Netherlands, and Poland. A finite mixture model estimates the probability of belonging to different latent classes of decision-makers. The results show that German and Dutch farmers are willing to contribute more on average (70% and 75% of the initial endowment respectively) than Polish and Hungarian farmers (57% and 50% of the initial endowment respectively). German and Dutch farmers can be categorised into two different classes, whereas in Hungary and Poland, three different classes of farmers are evident. The higher prevalence of freeriding observed in Hungary and Poland calls into question collective schemes that have to onboard everyone for example for rewetting a landscape. The overall heterogeneity in farmers' willingness to cooperate highlights that holistic approaches are necessary to promote collective AECMs among European farmers.