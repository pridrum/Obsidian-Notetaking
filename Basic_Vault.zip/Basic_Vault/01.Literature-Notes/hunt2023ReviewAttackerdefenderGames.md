---
CiteKey: hunt2023ReviewAttackerdefenderGames
Type: journalArticle
Title: "A review of attacker-defender games: Current state and paths forward"
Author: Kyle Hunt, Jun Zhuang
Publisher: ""
Journal: European Journal of Operational Research
Year: 2023
DOI: 10.1016/j.ejor.2023.04.009
Status: review
Main-Focus: review
---
>[!abstract] Summary
**A review of attacker-defender games: Current state and paths forward** 
**Author**: 'Kyle Hunt, Jun Zhuang' ;  2023
**Motivation**: 
**Research Questions or Gap**:  
**Methods**: 
**Results/Conclusions:** 
**Major take away:** 

>- **Project/Area:**
>- **Tags**: #Game-theory #Resource-allocation #Security #to-read #Defense #Terrorism 

---
# Highlights and comments

> [!Quote]  

- <mark style="background: yellow">.</mark> attacker-defender games


- <mark style="background: yellow">.</mark> systematic literature review methodology


- <mark style="background: yellow">.</mark> 127 journal articles that have been published over the past 15 years


- <mark style="background: red">.</mark> the sequence of moves, number of players, nature of decision variables and objective functions, and time horizons


- <mark style="background: yellow">.</mark> we examine the methods that have been adopted to solve attacker-defender games.


- <mark style="background: yellow">.</mark> We find that the majority of the articles obtain closed-form solutions to their models, while there are also many articles that developed novel solution algorithms and heuristics.




---
## Reference
>- **Ref**: [[hunt2023ReviewAttackerdefenderGames]]
>- **DOI**: 10.1016/j.ejor.2023.04.009
>- **Url**: https://www.sciencedirect.com/science/article/pii/S0377221723002916
>- **Uri**: http://zotero.org/users/2191306/items/ZGK33E2A
>- **Eprint**: 
>- **File**: 
>- **Keywords**: 
>- **PDF link**: [Hunt and Zhuang - 2024 - A review of attacker-defender games Current state.pdf](file://C:\Users\deazevedodrummond.p.NUNET\Zotero\storage\FXKCTPCG\Hunt%20and%20Zhuang%20-%202024%20-%20A%20review%20of%20attacker-defender%20games%20Current%20state.pdf)
>- **Local Library**: [Zotero]()
>- **Abstract**: In this article, we review the literature which proposes attacker-defender games to protect against strategic adversarial threats. More specifically, …