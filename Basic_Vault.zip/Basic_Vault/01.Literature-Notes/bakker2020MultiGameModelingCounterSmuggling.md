---
CiteKey: bakker2020MultiGameModelingCounterSmuggling
Type: journalArticle
Title: Multi-Game Modeling for Counter-Smuggling
Author: Craig Bakker, Jennifer B. Webster, Kathleen E. Nowak, Samrat Chatterjee, Casey J. Perkins, Robert Brigantic
Publisher: ""
Journal: Reliability Engineering & System Safety
Year: 2020
DOI: 10.1016/j.ress.2020.106958
Status: process
Main-Focus: model
---

>[!abstract] Summary
**Multi-Game Modeling for Counter-Smuggling** 
**Author**: 'Craig Bakker, Jennifer B. Webster, Kathleen E. Nowak, Samrat Chatterjee, Casey J. Perkins, Robert Brigantic' ;  2020
**Motivation**: 
**Research Questions or Gap**:  
**Methods/Algorithm**: 
**Field of Application:**
**Results/Conclusions:** 
**Major take away:** 

>- **Project/Area:**
>- **Tags**: #Game-Theory #Counter-Smuggling #Counter-Terrorism #Deterrence #Port-Security 

---
# Highlights and comments

> [!Quote]  



---
## Reference
>- **Ref**:[[bakker2020MultiGameModelingCounterSmuggling]]
>- **DOI**: 10.1016/j.ress.2020.106958
>- **Url**: https://www.sciencedirect.com/science/article/pii/S0951832018315060
>- **Uri**: http://zotero.org/users/2191306/items/P2N86VFJ
>- **Eprint**: 
>- **File**: 
>- **Keywords**: 
>- **PDF link**: [Bakker et al. - 2020 - Multi-Game Modeling for Counter-Smuggling.pdf](file://C:\Users\deazevedodrummond.p.NUNET\Zotero\storage\PY7WYXGS\Bakker%20et%20al.%20-%202020%20-%20Multi-Game%20Modeling%20for%20Counter-Smuggling.pdf)
>- **Local Library**: [Zotero]()
>- **Abstract**: International trade provides an avenue for terrorists to smuggle illicit materials into a target country. Policymakers need models and decision support tools that are both reliable and germane to inform their responses to this. Game theoretic approaches have been used in the analysis of counterterrorism strategies, but the models involved have often been small and abstracted. To address this need, we have developed a multi-game model to account for both security-related and economic aspects of counter-smuggling interdiction efforts. We use different games to represent different types of interactions, and these games are then coupled to each other to form an integrated model. In this paper, we demonstrate the model’s capabilities on a representative system of ports (both foreign and domestic), trade routes, and commodities. We specifically investigate the impacts of changes in screening policies at domestic ports, detection device capabilities, shipping subsidies, and worldwide corruption levels. In these studies, we find that economic factors play a large role in the interdiction task and provide correspondingly important tools for deterrence.