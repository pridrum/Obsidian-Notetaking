---
Authors: 
Year: 
Ref: 
Type: mine
Topic: 
Project/Area: 
Status: write, done, incubate
---
>[!idea] Main idea:  
>Interdiction Games

The idea that Games can be used to model interdiction problems, where we have a Agent trying to defend something while other are  were modelled in the seminal paper by [[Wood, 1998]]

[[hunt2023ReviewAttackerdefenderGames]] presents us with a review on all the games in the last 15 (from 2023). They summarize...

[[amon2023ExploringHeterogeneityFarmers]] also 