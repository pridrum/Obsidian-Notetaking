# 1. Creating Citations from your Outlines

Template for pulling all citations from the "Example Essay" from the 01.Literature-Notes" folder that I reference in this note. 

```dataview
TABLE DOI FROM outgoing([[Example Essay]]) AND "01.Literature-Notes"
```

This allows you to copy paste a list of referenced DOIs. 
Paste your DOI list to [Bibtex](https://www.bibtex.com/c/doi-to-bibtex-converter/)  to generate a list of citations in the correct format. 
