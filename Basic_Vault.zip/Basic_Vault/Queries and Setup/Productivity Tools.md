
# Open To-dos

I can add todos into my daily tasks and show them here in one list. 

```dataview
TASK from "Daily Notes" where !completed group by file.link
```

----

# Timeline 

An example timeline displaying one dot per source note I have added on that day. It gives me an overview of how much i have read. Just as a motivation. (You might need to step back to Dec 2022, to see any "action").

```dataview
Calendar file.ctime from "01.Literature-Notes"
```

