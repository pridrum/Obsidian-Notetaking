Other queries:  [DQL, JS and Inlines - Dataview (blacksmithgu.github.io)](https://blacksmithgu.github.io/obsidian-dataview/queries/dql-js-inline/)

# List of papers

List papers that are connected with a specific tag or topic (any metadata you used)


```dataview
Table Main-Focus, Year from "01.Literature-Notes"
```

## List of papers with a specific Tag (Game-Theory AND Terrorism)
```dataview
LIST From #Game-theory AND #Terrorism 
```
----

