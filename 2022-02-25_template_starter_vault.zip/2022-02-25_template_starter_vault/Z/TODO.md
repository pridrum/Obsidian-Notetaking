```todoist
{
"name": "My Tasks",
"filter": "today | overdue"
}
```

| 🟩️           | 🟨️           | 🟧️           | 🟥️           |
| ------------- | ------------- | ------------- | ------------- |
| ![[#^b3580a]] | ![[#^d7a3be]] | ![[#^77a800]] | ![[#^ae177d]] |

```query
tag:✅️/🟥️
```

^ae177d

```query
tag:✅️/🟧️
```

^77a800

```query
tag:✅️/🟨️
```

^d7a3be

```query
tag:✅️/🟩️
```

^b3580a

```query
content:/\-\ \[\ \]\ /
```
