```dialogue
left: <% tp.file.cursor(0) %>
right: <% tp.file.cursor(1) %>

< <% tp.file.cursor(2) %>
> <% tp.file.cursor(3) %>
```