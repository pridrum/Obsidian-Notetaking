---
tags: 🧠️/📥️/📜️/🟥️
publish: true
aliases: {{citekey}}
type: paper
status: 🟥️
created: 
updated: 
---

# Title: **[[& <%tp.date.now("YYYY-MM-DD")%> {{title}}]]**

## Metadata:

- type:: [[&]]
- author:: {{author}}
	- notable_authors:: 
- keywords:: {{Tags}}
- specific_subject:: 
- general_subject:: 
- doi:: {{DOI}}
- zotero_url:: {{localLibrary}}
- publish_date:: 
- reviewed_date:: 
- {{dateAdded}}
- collections:: {{collections}}
- related:: {{related}}
- pdf_attachments:: {{pdfAttachments}}
- abstract_note:: {{abstractNote}}


## Citation

```latex

```

## Hypothesis:

- 

## Methodology:

- 

## Result(s):

- 

## Summary of key points:

- 

## Notes