```dataview
table
from
where
sort
```