---
tags: 🧠️/📝️/🌱️
publish: true
aliases: 
---

# [[<%tp.file.title%>]]

---

<%tp.file.cursor(2)%>

---

- Tags: 
	- 
- Reference:
	- 
- Related:
	- 