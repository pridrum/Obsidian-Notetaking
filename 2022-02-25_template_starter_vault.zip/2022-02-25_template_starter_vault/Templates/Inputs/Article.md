---
tags: 🧠️/📥️/📰️/🟥️
publish: true
aliases: 
type: article
status: 🟥️
---

- `Title:` [[<%tp.file.title%>]]
- `Type:` [[(]]
- `Tags:` 
- `Author:` 
	- `Notable Authors:` 
- `Link:` 
- `Reference:` 
- `Publish Date:` 
- `Reviewed Date:` [[<%tp.date.now()%>]]

---

- 