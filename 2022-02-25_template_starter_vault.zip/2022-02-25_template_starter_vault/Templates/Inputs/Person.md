---
tags: 🧠️/👥️
publish: true
---

# [[Person]]

- `Type:` [[@]]
- `Keywords:`
- `Profession:`
- `If / How we met:`
- `Shared interests:`
- `Connection Points:`