---
tags: 🧠️/📥️/💭️/🟥️
publish: true
aliases:
  - 
cssclass: 
type: thought
status: 🟥️
---

- `Title:` [[<%tp.file.title%>]]
- `Type:` [[=]]
- `Tags:` 
- `Formation Date:` [[<%tp.date.now()%>]]

---

- `The Thought:`
	- `tl;dr`
	- `Chew On It:`
	- `Refined`
- `Relevant Context:`
- `What Led Me Here:`