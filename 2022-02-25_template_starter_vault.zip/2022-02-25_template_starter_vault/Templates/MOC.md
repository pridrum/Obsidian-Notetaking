---
tags: 🧠️/🗺️
publish: true
aliases:
  - null
cssclass: null
---

#### [[<%tp.file.title%>]]

---

<%tp.file.cursor(1)%>